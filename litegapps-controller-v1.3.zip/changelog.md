**v1.3**
- Added Gapps Check
- Add DT2W Enable
- Support A16

**v1.2**
- Remove Download packages menu
- Added change fingeprint props
- Adden fix late notification
- Adden clean memory
